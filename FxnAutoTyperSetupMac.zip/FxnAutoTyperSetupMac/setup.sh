#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$SCRIPT_DIR/fxn_typer.app"

echo "Removing quarantine..."
xattr -dr com.apple.quarantine "$APP"

echo "Setting executable permission..."
chmod +x "$APP/Contents/MacOS/FxnAutoTyperMac"

echo ""
echo "Finished!"
echo "Press Enter to exit."
read
